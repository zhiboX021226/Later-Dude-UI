﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace user_interface
{
    public partial class Scan : Form
    {
        public Scan()
        {
            InitializeComponent();
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            listBoxFiles.Items.Clear();
            listBoxFiles.Refresh();
            DirectoryInfo dinfo = new DirectoryInfo(@"D:\wav");
            FileInfo[] Files = dinfo.GetFiles("*.wav");
            foreach ( FileInfo file in Files)
            {
                listBoxFiles.Items.Add(file.Name);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            listBoxFiles.Items.Clear();
            listBoxFiles.Refresh();
        }
    }
}
