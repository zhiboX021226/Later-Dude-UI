﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace user_interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            panel3.Height = btuDashboard.Height;
            panel3.Top = btuDashboard.Top;
            panel3.Left = btuDashboard.Left;
            btuDashboard.BackColor = Color.FromArgb(46, 51, 73);

            lblTitle.Text = "Check File";
            this.PnlFormLoader.Controls.Clear();
            frmDashboard FrmDashboard_Vrb = new frmDashboard() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            FrmDashboard_Vrb.FormBorderStyle = FormBorderStyle.None;
            this.PnlFormLoader.Controls.Add(FrmDashboard_Vrb);
            FrmDashboard_Vrb.Show();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btuDashboard_Click(object sender, EventArgs e)
        {
            panel3.Height = btuDashboard.Height;
            panel3.Top = btuDashboard.Top;
            panel3.Left = btuDashboard.Left;
            btuDashboard.BackColor = Color.FromArgb(46, 51, 73);

            lblTitle.Text = "Check File";
            this.PnlFormLoader.Controls.Clear();
            frmDashboard FrmDashboard_Vrb = new frmDashboard() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            FrmDashboard_Vrb.FormBorderStyle = FormBorderStyle.None;
            this.PnlFormLoader.Controls.Add(FrmDashboard_Vrb);
            FrmDashboard_Vrb.Show();
        }

        private void btuDashboard_Leave(object sender, EventArgs e)
        {
            btuDashboard.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            panel3.Height = btnSettings.Height;
            panel3.Top = btnSettings.Top;
            panel3.Left = btnSettings.Left;
            btnSettings.BackColor = Color.FromArgb(46, 51, 73);

            Application.Exit();
        }

        private void btnSettings_Leave(object sender, EventArgs e)
        {
            btnSettings.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnInject_Click(object sender, EventArgs e)
        {
            panel3.Height = btnInject.Height;
            panel3.Top = btnInject.Top;
            panel3.Left = btnInject.Left;
            btnInject.BackColor = Color.FromArgb(46, 51, 73);

            lblTitle.Text = "Send to Later Dude";
            this.PnlFormLoader.Controls.Clear();
            frmInject FrmInject_Vrb = new frmInject() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            FrmInject_Vrb.FormBorderStyle = FormBorderStyle.None;
            this.PnlFormLoader.Controls.Add(FrmInject_Vrb);
            FrmInject_Vrb.Show();
        }


        private void btnInject_Leave_1(object sender, EventArgs e)
        {
            btnInject.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
  
        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

       

        private void pnlNav_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            panel3.Height = btnScaner.Height;
            panel3.Top = btnScaner.Top;
            panel3.Left = btnScaner.Left;
            btnScaner.BackColor = Color.FromArgb(46, 51, 73);

            lblTitle.Text = "Scaner";
            this.PnlFormLoader.Controls.Clear();
            Scan FrmScan_Vrb = new Scan() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            FrmScan_Vrb.FormBorderStyle = FormBorderStyle.None;
            this.PnlFormLoader.Controls.Add(FrmScan_Vrb);
            FrmScan_Vrb.Show();
        }

        private void btnScaner_Leave(object sender, EventArgs e)
        {
            btnScaner.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnMycroft_Click(object sender, EventArgs e)
        {
            panel3.Height = btnMycroft.Height;
            panel3.Top = btnMycroft.Top;
            panel3.Left = btnMycroft.Left;
            btnMycroft.BackColor = Color.FromArgb(46, 51, 73);

            lblTitle.Text = "Mycroft";
            this.PnlFormLoader.Controls.Clear();
            frmMycroft FrmMycroft_Vrb = new frmMycroft() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            FrmMycroft_Vrb.FormBorderStyle = FormBorderStyle.None;
            this.PnlFormLoader.Controls.Add(FrmMycroft_Vrb);
            FrmMycroft_Vrb.Show();
        }

        private void btnMycroft_Leave(object sender, EventArgs e)
        {
            btnMycroft.BackColor = Color.FromArgb(24, 30, 54);
        }
    }
}
