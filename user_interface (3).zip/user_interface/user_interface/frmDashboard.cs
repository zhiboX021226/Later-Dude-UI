﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace user_interface
{
    public partial class frmDashboard : Form
    {
        SoundPlayer player;
        public frmDashboard()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "WAV|*.wav*", Multiselect = false, ValidateNames = true })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                    textFileName.Text = ofd.FileName;
                
            }
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textFileName.Text))
                return;
            try
            {
                player.SoundLocation = textFileName.Text;
                player.PlayLooping();
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            player.Stop();
        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {
            player = new SoundPlayer();
        }

        private void btnGetFileDetails_Click(object sender, EventArgs e)
        {
            OpenFileDialog fDialog = new OpenFileDialog();

            if (fDialog.ShowDialog() != DialogResult.OK)

                return;

            System.IO.FileInfo fInfo = new System.IO.FileInfo(fDialog.FileName);
            DateTime ctime = fInfo.CreationTime;
            DateTime mtime = fInfo.LastWriteTime;

            textCreated.Text = ctime.ToString();
            textModified.Text = mtime.ToString();
        }
    }
}
